import { NextRequest, NextResponse } from "next/server";

// Server-side only env var (no NEXT_PUBLIC_ prefix) so the model API URL
// is never sent to the browser and CORS never becomes the client's problem.
// Set this in Vercel/​.env.local, e.g.:
//   MODEL_API_URL=https://<your-username>-<space-name>.hf.space/predict
const MODEL_API_URL = process.env.MODEL_API_URL;

export const runtime = "nodejs";
export const maxDuration = 60; // seconds — Hugging Face free-tier Spaces can cold-start slowly

export async function POST(req: NextRequest) {
  if (!MODEL_API_URL) {
    return NextResponse.json(
      { success: false, error: "MODEL_API_URL is not configured on the server." },
      { status: 500 }
    );
  }

  let incomingForm: FormData;
  try {
    incomingForm = await req.formData();
  } catch {
    return NextResponse.json(
      { success: false, error: "Expected multipart/form-data with an image file." },
      { status: 400 }
    );
  }

  const file = incomingForm.get("file");
  if (!file) {
    return NextResponse.json({ success: false, error: "No file uploaded." }, { status: 400 });
  }

  const forwardForm = new FormData();
  forwardForm.append("file", file);

  try {
    const modelRes = await fetch(MODEL_API_URL, {
      method: "POST",
      body: forwardForm,
      signal: AbortSignal.timeout(55_000),
    });

    const data = await modelRes.json();

    if (!modelRes.ok) {
      return NextResponse.json(
        { success: false, error: data.error || "Model API returned an error." },
        { status: modelRes.status }
      );
    }

    return NextResponse.json(data);
  } catch (err) {
    console.error("predict proxy error:", err);
    return NextResponse.json(
      {
        success: false,
        error:
          "Could not reach the model API. If it's hosted on Hugging Face's free tier it may be asleep — wait ~30s and try again.",
      },
      { status: 502 }
    );
  }
}
