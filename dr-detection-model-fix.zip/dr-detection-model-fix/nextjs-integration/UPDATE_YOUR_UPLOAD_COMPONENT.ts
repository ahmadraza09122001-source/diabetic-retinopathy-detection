/**
 * REFERENCE ONLY — this shows the one line that matters in your existing
 * upload component. You almost certainly already have a component that
 * builds a FormData and does something like:
 *
 *   fetch("http://127.0.0.1:5000/predict", { method: "POST", body: formData })
 *
 * That hardcoded 127.0.0.1 is the main reason it fails for anyone but you,
 * on your machine, with the Flask server already running. Change it to call
 * your OWN Next.js route instead — same request shape, so nothing else
 * about your component needs to change:
 *
 *   fetch("/api/predict", { method: "POST", body: formData })
 *
 * Full example:
 */

async function handleUpload(file: File) {
  const formData = new FormData();
  formData.append("file", file); // field name must be "file" to match the API route

  const res = await fetch("/api/predict", {
    method: "POST",
    body: formData,
  });

  const data = await res.json();

  if (!data.success) {
    // data.error is a human-readable message set by the API route or the model API
    throw new Error(data.error);
  }

  return data; // { label, predicted_class, confidence, all_probabilities }
}
