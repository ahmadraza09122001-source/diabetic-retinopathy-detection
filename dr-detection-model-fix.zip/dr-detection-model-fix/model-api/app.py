import os
import io
import time
import logging
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import tensorflow as tf

# ---------------------------------------------------------------------------
# Logging (same style as the original model.log so it's easy to compare)
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
log = logging.getLogger("model")

app = Flask(__name__)
CORS(app)  # allow the Next.js app (or anyone, while testing) to call this API directly

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
MODEL_PATH = os.environ.get("MODEL_PATH", "model.keras")
# ^ Rename your real model file to model.keras when you upload it (recommended —
# avoids "(", ")", "%" in the filename), or set the MODEL_PATH env var in your
# Space's Settings to your file's exact name if you'd rather not rename it.
IMG_SIZE = (224, 224)
CLASS_NAMES = ["No_DR", "Mild", "Moderate", "Severe", "Proliferative_DR"]  # APTOS-style 5-class DR grading — adjust to match your training labels

model = None
model_load_seconds = None


def load_model():
    """Loads the model once at process startup. Runs in the main thread
    BEFORE gunicorn starts accepting requests, so a slow load delays
    startup rather than causing per-request failures."""
    global model, model_load_seconds
    log.info("Current working directory: %s", os.getcwd())
    log.info("Loading model from: %s", MODEL_PATH)

    if not os.path.exists(MODEL_PATH):
        log.error("Model file not found at %s — check it was uploaded/committed (see README).", MODEL_PATH)
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")

    t0 = time.time()
    model = tf.keras.models.load_model(MODEL_PATH)
    model_load_seconds = time.time() - t0
    log.info("Model loaded successfully in %.1fs. Input shape: %s", model_load_seconds, model.input_shape)


def preprocess(image_bytes):
    """Turns the uploaded image bytes into the 3 tensors the ensemble expects.

    ASSUMPTION: all three branches were trained on identically-preprocessed
    copies of the same image (a common pattern for 3-backbone ensembles).
    If your real model trained each branch with different preprocessing
    (e.g. tf.keras.applications.efficientnet.preprocess_input for branch 1,
    a different normalization for branch 2, etc.) duplicate this function
    per-branch and adjust before np.expand_dims.
    """
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB").resize(IMG_SIZE)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    arr = np.expand_dims(arr, axis=0)  # (1, 224, 224, 3)
    return [arr, arr, arr]


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok" if model is not None else "model_not_loaded",
        "model_load_seconds": model_load_seconds,
    })


@app.route("/predict", methods=["POST"])
def predict():
    if model is None:
        return jsonify({"success": False, "error": "Model is not loaded yet. Check /health."}), 503

    file = request.files.get("file") or request.files.get("image")
    if file is None:
        return jsonify({"success": False, "error": "No file uploaded. Send multipart/form-data with field name 'file'."}), 400

    try:
        inputs = preprocess(file.read())
        preds = model.predict(inputs, verbose=0)[0]
    except Exception as e:
        log.exception("Prediction failed")
        return jsonify({"success": False, "error": f"Prediction failed: {e}"}), 500

    predicted_idx = int(np.argmax(preds))
    return jsonify({
        "success": True,
        "label": CLASS_NAMES[predicted_idx],
        "predicted_class": predicted_idx,
        "confidence": float(preds[predicted_idx]),
        "all_probabilities": {name: float(p) for name, p in zip(CLASS_NAMES, preds)},
    })


# Load once at import time so both `python app.py` (dev) and gunicorn (prod) trigger it.
load_model()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 7860)))
