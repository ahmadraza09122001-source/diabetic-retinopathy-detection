"""
Generates a tiny placeholder .keras model with the SAME input signature
reported in the user's model.log:
    Input shape: [(None, 224, 224, 3), (None, 224, 224, 3), (None, 224, 224, 3)]

This stands in for the real `2025(84%).keras` ensemble model so we can prove
the Flask/Docker/HF Spaces serving scaffold actually loads a model and
returns predictions end-to-end. Swap this file out for the real model.
"""
import tensorflow as tf
from tensorflow.keras import layers, Model

def make_branch(name):
    inp = layers.Input(shape=(224, 224, 3), name=f"input_{name}")
    x = layers.Conv2D(8, 3, activation="relu")(inp)
    x = layers.GlobalAveragePooling2D()(x)
    return inp, x

inp1, b1 = make_branch("a")
inp2, b2 = make_branch("b")
inp3, b3 = make_branch("c")

merged = layers.Concatenate()([b1, b2, b3])
out = layers.Dense(5, activation="softmax", name="dr_grade")(merged)  # 5 DR severity classes (0-4)

model = Model(inputs=[inp1, inp2, inp3], outputs=out)
model.compile(optimizer="adam", loss="categorical_crossentropy")
model.save("2025(84%).keras")
print("Saved dummy model. Input shape:", model.input_shape)
