---
title: DR Detection Model API
emoji: 👁️
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
pinned: false
---

# Diabetic Retinopathy — Model API

A small Flask API that loads the trained `.keras` ensemble model and serves
predictions over HTTP, meant to be called from the Next.js frontend (or
anything else) instead of a hardcoded `127.0.0.1` address.

## Endpoints

- `GET /health` → `{"status": "ok", "model_load_seconds": <float>}`
- `POST /predict` → multipart/form-data with field `file` (an image) →
  `{"success": true, "label": "...", "predicted_class": 0-4, "confidence": 0.0-1.0, "all_probabilities": {...}}`

## Before you deploy: add your real model

1. Rename your trained model file to `model.keras` and drop it in this folder
   (next to `app.py`), **or** keep its original name and set the `MODEL_PATH`
   environment variable in this Space's *Settings → Variables and secrets*.
2. If the file is over ~10MB, track it with Git LFS before pushing:
   ```bash
   git lfs install
   git lfs track "*.keras"
   git add .gitattributes model.keras
   git commit -m "Add trained model"
   git push
   ```
3. Check the *Logs* tab after the Space builds. You're looking for the same
   line your local `model.log` produced: `Model loaded successfully in Xs.
   Input shape: ...`. If loading still takes anywhere near the ~25 minutes it
   took locally, see the "Slow model load" note in the main SETUP_GUIDE.md —
   that will time out this platform (and most others) before it finishes.

## Testing this Space once it's live

```bash
curl https://<your-username>-<space-name>.hf.space/health

curl -X POST -F "file=@sample_retina.jpg" \
  https://<your-username>-<space-name>.hf.space/predict
```
